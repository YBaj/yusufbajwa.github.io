package com.example.module5app

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class UserDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "WeightApp.db"
        private const val DATABASE_VERSION = 1
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create Users table
        val createUsersTable = """
            CREATE TABLE Users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT
            )
        """.trimIndent()
        db.execSQL(createUsersTable)

        // Create Weights table
        val createWeightsTable = """
            CREATE TABLE Weights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                date TEXT,
                weight REAL,
                FOREIGN KEY(user_id) REFERENCES Users(id)
            )
        """.trimIndent()
        db.execSQL(createWeightsTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Users")
        db.execSQL("DROP TABLE IF EXISTS Weights")
        onCreate(db)
    }

    // ----------------------
    // User functions
    // ----------------------
    fun addUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        val result = db.insert("Users", null, values)
        db.close()
        return result != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor: Cursor = db.query(
            "Users",
            arrayOf("id"),
            "username=? AND password=?",
            arrayOf(username, password),
            null, null, null
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    fun getUserId(username: String): Int {
        val db = readableDatabase
        val cursor: Cursor = db.query(
            "Users",
            arrayOf("id"),
            "username=?",
            arrayOf(username),
            null, null, null
        )
        var id = -1
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
        }
        cursor.close()
        db.close()
        return id
    }

    // ----------------------
    // Weight functions
    // ----------------------
    fun addWeight(userId: Int, date: String, weight: Double): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("user_id", userId)
            put("date", date)
            put("weight", weight)
        }
        val result = db.insert("Weights", null, values)
        db.close()
        return result != -1L
    }

    fun getWeights(userId: Int): Cursor {
        val db = readableDatabase
        return db.query(
            "Weights",
            arrayOf("id", "date", "weight"),
            "user_id=?",
            arrayOf(userId.toString()),
            null, null,
            "date ASC"
        )
    }

    fun updateWeight(weightId: Int, newWeight: Double, newDate: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("weight", newWeight)
            put("date", newDate)
        }
        val result = db.update("Weights", values, "id=?", arrayOf(weightId.toString()))
        db.close()
        return result > 0
    }

    fun deleteWeight(weightId: Int): Boolean {
        val db = writableDatabase
        val result = db.delete("Weights", "id=?", arrayOf(weightId.toString()))
        db.close()
        return result > 0
    }
}
