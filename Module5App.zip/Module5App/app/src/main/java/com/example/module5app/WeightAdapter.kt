package com.example.module5app

import android.database.Cursor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeightAdapter(
    private val cursor: Cursor,
    private val dbHelper: UserDatabaseHelper
) : RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

    class WeightViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dateText: TextView = itemView.findViewById(R.id.dateText)
        val weightText: TextView = itemView.findViewById(R.id.weightText)
        val removeButton: Button = itemView.findViewById(R.id.removeButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WeightViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.weight_item, parent, false)
        return WeightViewHolder(view)
    }

    override fun getItemCount(): Int = cursor.count

    override fun onBindViewHolder(holder: WeightViewHolder, position: Int) {
        if (cursor.moveToPosition(position)) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
            val date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
            val weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))

            holder.dateText.text = date
            holder.weightText.text = weight.toString()

            holder.removeButton.setOnClickListener {
                dbHelper.deleteWeight(id)
                notifyItemRemoved(position)
                notifyItemRangeChanged(position, itemCount)
            }
        }
    }
}
