package com.example.module5app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.database.Cursor

class DataGridScreen : AppCompatActivity() {

    private lateinit var databaseHelper: UserDatabaseHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: WeightAdapter
    private var userId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.data_grid_screen)

        databaseHelper = UserDatabaseHelper(this)
        recyclerView = findViewById(R.id.weightsRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Get user ID from LoginScreen
        userId = intent.getIntExtra("userId", -1)
        if (userId == -1) {
            Toast.makeText(this, "Error loading user data", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        findViewById<Button>(R.id.addWeightButton).setOnClickListener {
            showAddWeightDialog()
        }

        loadWeights()
    }

    private fun loadWeights() {
        val cursor = databaseHelper.getWeights(userId)
        adapter = WeightAdapter(cursor, databaseHelper)
        recyclerView.adapter = adapter

        val averageWeight = calculateAverageWeight(cursor)
        Toast.makeText(
            this,
            "Average Weight: $averageWeight",
            Toast.LENGTH_SHORT
        ).show()
    }

    // Enhancement: extract values into a list and apply an algorithm
    private fun calculateAverageWeight(cursor: Cursor): Double {
        val weights = mutableListOf<Double>()

        if (cursor.moveToFirst()) {
            do {
                val weight =
                    cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))
                weights.add(weight)
            } while (cursor.moveToNext())
        }

        return if (weights.isNotEmpty()) {
            weights.average()
        } else {
            0.0
        }
    }

    private fun showAddWeightDialog() {
        val dialogView = layoutInflater.inflate(
            R.layout.dialog_add_weight,
            null
        )

        val dateInput =
            dialogView.findViewById<EditText>(R.id.editTextDate)
        val weightInput =
            dialogView.findViewById<EditText>(R.id.editTextWeight)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add Weight")
            .setView(dialogView)
            .create()

        dialogView.findViewById<Button>(R.id.buttonAddWeight)
            .setOnClickListener {

                val date = dateInput.text.toString()
                val weight =
                    weightInput.text.toString().toDoubleOrNull()

                if (weight != null && date.isNotBlank()) {
                    databaseHelper.addWeight(userId, date, weight)
                    loadWeights()
                    dialog.dismiss()
                } else {
                    Toast.makeText(
                        this,
                        "Enter valid date and weight",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        dialog.show()
    }

    // --------------------------
    // RecyclerView Adapter
    // --------------------------
    inner class WeightAdapter(
        private var cursor: Cursor,
        private val dbHelper: UserDatabaseHelper
    ) : RecyclerView.Adapter<WeightAdapter.WeightViewHolder>() {

        inner class WeightViewHolder(view: View) :
            RecyclerView.ViewHolder(view) {

            val dateText: TextView =
                view.findViewById(R.id.dateText)
            val weightText: TextView =
                view.findViewById(R.id.weightText)
            val removeButton: Button =
                view.findViewById(R.id.removeButton)
        }

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int
        ): WeightViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.weight_item, parent, false)
            return WeightViewHolder(view)
        }

        override fun getItemCount(): Int = cursor.count

        override fun onBindViewHolder(
            holder: WeightViewHolder,
            position: Int
        ) {
            if (cursor.moveToPosition(position)) {
                val id =
                    cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val date =
                    cursor.getString(cursor.getColumnIndexOrThrow("date"))
                val weight =
                    cursor.getDouble(cursor.getColumnIndexOrThrow("weight"))

                holder.dateText.text = date
                holder.weightText.text = weight.toString()

                holder.removeButton.setOnClickListener {
                    dbHelper.deleteWeight(id)
                    loadWeights()
                }
            }
        }
    }
}
