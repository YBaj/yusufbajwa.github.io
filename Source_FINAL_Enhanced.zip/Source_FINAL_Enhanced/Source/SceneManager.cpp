///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//  MODIFIED BY: [Yusuf Bajwa] - Added lighting implementation
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";

    // Lighting-related uniform names
    const char* g_LightPosName = "lightPos";
    const char* g_LightColorName = "lightColor";
    const char* g_Light2PosName = "light2Pos";
    const char* g_Light2ColorName = "light2Color";
    const char* g_ViewPosName = "viewPosition";

    // third light uniform names
    const char* g_Light3PosName = "light3Pos";
    const char* g_Light3ColorName = "light3Color";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // indicate to always flip images vertically when loaded
    stbi_set_flip_vertically_on_load(true);

    // try to parse the image data from the specified image file
    unsigned char* image = stbi_load(
        filename,
        &width,
        &height,
        &colorChannels,
        0);

    // if the image was successfully read from the image file
    if (image)
    {
        std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // (kept behavior, mipmapped)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // if the loaded image is in RGB format
        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        // if the loaded image is in RGBA format - it supports transparency
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            stbi_image_free(image);
            glBindTexture(GL_TEXTURE_2D, 0);
            return false;
        }

        // generate the texture mipmaps for mapping textures to lower resolutions
        glGenerateMipmap(GL_TEXTURE_2D);

        // free the image data from local memory
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        // register the loaded texture and associate it with the special tag string
        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;

    // Error loading the image
    return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // NOTE: this was glGenTextures in some templates; freeing uses glDeleteTextures
        if (m_textureIDs[i].ID != 0)
        {
            glDeleteTextures(1, &m_textureIDs[i].ID); // fix resource cleanup
            m_textureIDs[i].ID = 0;
        }
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return(false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.ambientColor = m_objectMaterials[index].ambientColor;
            material.ambientStrength = m_objectMaterials[index].ambientStrength;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    // variables for this method
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    // set the scale value in the transform buffer
    scale = glm::scale(scaleXYZ);
    // set the rotation values in the transform buffer
    rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    // set the translation value in the transform buffer
    translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    // variables for this method
    glm::vec4 currentColor;

    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = -1;
        textureID = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = false;

        bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
            m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Load basic meshes
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();

    // meshes for notebook and mug handle
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadTorusMesh();

    // Load textures for the scene
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/rusticwood.jpg", "desk");
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/stainless.jpg", "pen_body");
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/stainless_end.jpg", "pen_tip");
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/abstract.jpg", "pen_label");

    // notebook + mug textures
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/paper.jpg", "notebook_pages");
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/leather.jpg", "notebook_cover");
    CreateGLTexture("C:/Users/yusuf/Downloads/CS330Content/CS330Content/Utilities/textures/ceramic.jpg", "mug");

    // Define materials for lighting
    OBJECT_MATERIAL woodMaterial;
    woodMaterial.ambientColor = glm::vec3(0.3f, 0.2f, 0.1f);
    woodMaterial.ambientStrength = 0.3f;
    woodMaterial.diffuseColor = glm::vec3(0.6f, 0.5f, 0.4f);
    woodMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
    woodMaterial.shininess = 32.0f;
    woodMaterial.tag = "wood";
    m_objectMaterials.push_back(woodMaterial);

    OBJECT_MATERIAL metalMaterial;
    metalMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
    metalMaterial.ambientStrength = 0.3f;
    metalMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
    metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
    metalMaterial.shininess = 128.0f;
    metalMaterial.tag = "metal";
    m_objectMaterials.push_back(metalMaterial);

    OBJECT_MATERIAL plasticMaterial;
    plasticMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
    plasticMaterial.ambientStrength = 0.3f;
    plasticMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
    plasticMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
    plasticMaterial.shininess = 64.0f;
    plasticMaterial.tag = "plastic";
    m_objectMaterials.push_back(plasticMaterial);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
    // declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Enable lighting and set up light sources
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseLightingName, true);

        // Main directional light (like sunlight)
        m_pShaderManager->setVec3Value(g_LightPosName, glm::vec3(-1.0f, 1.0f, -1.0f));
        m_pShaderManager->setVec3Value(g_LightColorName, glm::vec3(0.9f, 0.9f, 0.8f));

        // Secondary point light (fill light)
        m_pShaderManager->setVec3Value(g_Light2PosName, glm::vec3(0.0f, 2.0f, 2.0f));
        m_pShaderManager->setVec3Value(g_Light2ColorName, glm::vec3(0.4f, 0.4f, 0.5f));

        // third warm desk lamp light
        m_pShaderManager->setVec3Value(g_Light3PosName, glm::vec3(2.0f, 3.0f, 0.0f));
        m_pShaderManager->setVec3Value(g_Light3ColorName, glm::vec3(1.0f, 0.85f, 0.6f));

        // View position for specular calculations
        m_pShaderManager->setVec3Value(g_ViewPosName, glm::vec3(0.0f, 2.0f, 5.0f));
    }

    // Bind all loaded textures before rendering
    BindGLTextures();

    // =============================================
    // DESK (PLANE) WITH WOOD TEXTURE
    // =============================================
    scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderTexture("desk");
    SetShaderMaterial("wood"); // Apply wood material properties
    SetTextureUVScale(8.0f, 8.0f);
    m_basicMeshes->DrawPlaneMesh();

    // =============================================
    // PEN OBJECT
    // =============================================

    // PEN BODY (cylinder) - stainless steel base
    scaleXYZ = glm::vec3(0.05f, 0.05f, 1.5f);
    positionXYZ = glm::vec3(0.0f, 0.05f, 0.0f);
    XrotationDegrees = 0.0f; YrotationDegrees = 90.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderTexture("pen_body");
    SetShaderMaterial("metal"); // Apply metal material properties
    SetTextureUVScale(1.0f, 4.0f);
    m_basicMeshes->DrawCylinderMesh();

    // PEN BODY LABEL (cylinder) - abstract pattern overlay
    // NOTE: SetShaderColor() disables texture. If you intend the label to be textured, omit SetShaderColor here.
    SetShaderTexture("pen_label");
    SetShaderMaterial("plastic"); // Apply plastic material properties
    SetTextureUVScale(2.0f, 8.0f);
    SetShaderColor(1, 1, 1, 0.6f); // keeps your original logic
    m_basicMeshes->DrawCylinderMesh();

    // PEN TIP (cone) - different metal texture
    scaleXYZ = glm::vec3(0.05f, 0.05f, 0.2f);
    positionXYZ = glm::vec3(0.75f, 0.05f, 0.0f);
    XrotationDegrees = 0.0f; YrotationDegrees = 90.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderTexture("pen_tip");
    SetShaderMaterial("metal"); // Apply metal material properties
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // =============================================
    // NOTEBOOK OBJECT (box cover + pages)
    // =============================================
    // Cover (slightly larger base)
    scaleXYZ = glm::vec3(2.5f, 0.1f, 3.0f);
    positionXYZ = glm::vec3(-3.0f, 0.05f, 2.0f);
    XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderTexture("notebook_cover");
    SetShaderMaterial("plastic");
    SetTextureUVScale(2.0f, 2.0f);
    m_basicMeshes->DrawBoxMesh();

    // Pages (slightly smaller, above cover)
    scaleXYZ = glm::vec3(2.4f, 0.05f, 2.9f);
    positionXYZ = glm::vec3(-3.0f, 0.1f, 2.0f);
    XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderTexture("notebook_pages");
    SetShaderMaterial("wood"); // mild specular; you can make a 'paper' material if you want
    SetTextureUVScale(3.0f, 3.0f);
    m_basicMeshes->DrawBoxMesh();

    // =============================================
    // MUG OBJECT (cylinder body + torus handle)
    // =============================================
    // Mug body
    scaleXYZ = glm::vec3(0.5f, 0.5f, 0.7f);
    positionXYZ = glm::vec3(3.0f, 0.35f, -1.0f);
    XrotationDegrees = 0.0f; YrotationDegrees = 0.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderTexture("mug");
    SetShaderMaterial("plastic");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Mug handle (torus rotated to the side)
    scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);
    positionXYZ = glm::vec3(3.4f, 0.35f, -1.0f); // offset from mug body
    XrotationDegrees = 0.0f; YrotationDegrees = 90.0f; ZrotationDegrees = 0.0f;

    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("plastic");
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f); // solid white ceramic
    m_basicMeshes->DrawTorusMesh();
}
