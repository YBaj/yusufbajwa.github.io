package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@RestController
public class ChecksumController {

    @GetMapping("/hash")
    public String getHash(
            @RequestParam(value = "input", defaultValue = "yusuf-unique-string") String input) {

        try {
            String encodedHash = generateSha256Base64(input);
            return "Input: " + input + "\nChecksum (SHA-256, Base64): " + encodedHash;
        } catch (NoSuchAlgorithmException e) {
            return "Error: Algorithm SHA-256 not found.";
        }
    }

    private String generateSha256Base64(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(hashBytes);
    }
}