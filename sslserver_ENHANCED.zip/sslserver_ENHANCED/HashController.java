package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class HashController {

    @GetMapping("/hashchecksum")
    public String getChecksum() {
        String data = "Hello World Check Sum! - Yusuf Bajwa!";

        try {
            String hexHash = generateSha256Hex(data);
            return "Data: " + data + "\nChecksum: " + hexHash;
        } catch (NoSuchAlgorithmException e) {
            return "Error: SHA-256 algorithm not found.";
        }
    }

    private String generateSha256Hex(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));

        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            hexString.append(String.format("%02x", b));
        }
        return hexString.toString();
    }
}
